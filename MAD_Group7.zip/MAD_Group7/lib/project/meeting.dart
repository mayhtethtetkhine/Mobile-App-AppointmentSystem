import 'package:flutter/material.dart';

class Meeting {
  Meeting(this.title, this.from, this.to, this.background, this.idemail,
      this.location);

  String title;
  DateTime from;
  DateTime to;
  Color background;
  String idemail;
  String location;
}
