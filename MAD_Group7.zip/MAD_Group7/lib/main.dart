import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'project/first.dart';
import 'project/provider.dart';
import 'package:firebase_core/firebase_core.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider(
        create: (context) => AppointmentProvider(),
        child: MaterialApp(
          home: First(),
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            scaffoldBackgroundColor: Color.fromARGB(255, 255, 252, 247),
            inputDecorationTheme: InputDecorationTheme(
              labelStyle: TextStyle(color: Color.fromARGB(255, 117, 7, 7)),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.black),
              ),
            ),
            appBarTheme: AppBarTheme(
              backgroundColor:
                  Colors.transparent, // Make the AppBar transparent
              elevation: 3, // Remove the shadow underneath the AppBar
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color.fromARGB(255, 117, 7, 7),
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 13),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                textStyle: TextStyle(
                  fontSize: 16,
                ),
              ),
            ),
            bottomNavigationBarTheme: BottomNavigationBarThemeData(
              selectedItemColor: Color.fromRGBO(179, 139, 30, 1),
              unselectedItemColor: Colors.grey,
              showUnselectedLabels: true,
              selectedLabelStyle: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        )),
  );
}
