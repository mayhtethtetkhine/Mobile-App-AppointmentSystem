import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'first.dart';
import 'provider.dart';
import 's_home.dart';
import 's_register.dart';
import 'package:provider/provider.dart';

class SLogin extends StatefulWidget {
  const SLogin({super.key});

  @override
  State<SLogin> createState() => _SLoginState();
}

class _SLoginState extends State<SLogin> {
  final _formkey = GlobalKey<FormState>();
  final _userStream =
      FirebaseFirestore.instance.collection('student_data').snapshots();

  final _tcStudentID = TextEditingController();
  final _tcPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Student Login'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          //backgroundColor: Colors.red,
        ),
        body: StreamBuilder<QuerySnapshot>(
            stream: _userStream,
            builder: ((context, snapshot) {
              if (snapshot.hasError) {
                return Text('Connection error');
              }

              //is it connecting?
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text('Loading data ...');
              }

              //data is ready

              // convert data to list
              // var existing_data = snapshot.data!.docs;

              return Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Form(
                  key: _formkey,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _tcStudentID,
                          decoration: InputDecoration(
                            labelText: 'Student ID',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Student ID';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _tcPassword,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Password',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter password';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white),
                              onPressed: () {
                                //validate
                                //route
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => First()));
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Color.fromARGB(255, 117, 7, 7),
                              )),
                          SizedBox(
                            width: 20,
                          ),
                          ElevatedButton(
                              onPressed: () {
                                if (_formkey.currentState!.validate()) {
                                  FirebaseFirestore.instance
                                      .collection('student_data')
                                      .where('student id',
                                          isEqualTo: _tcStudentID.text)
                                      .limit(1)
                                      .get()
                                      .then((QuerySnapshot query) {
                                    var docs = query.docs;
                                    if (docs.isEmpty) {
                                      setState(() {
                                        //snackbar account does not exist
                                        ScaffoldMessenger.of(context)
                                            .removeCurrentSnackBar();
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(SnackBar(
                                          content:
                                              Text('Account does not exist. '),
                                          duration: Duration(seconds: 1),
                                        ));
                                      });
                                    } else {
                                      setState(() {
                                        // docs[0]['name']
                                        if (docs[0]['s password'] ==
                                            _tcPassword.text) {
                                          context
                                              .read<AppointmentProvider>()
                                              .set_student(_tcStudentID.text);
                                          ScaffoldMessenger.of(context)
                                              .removeCurrentSnackBar();
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                            content: Text('Logged In.'),
                                            duration: Duration(seconds: 1),
                                          ));
                                          Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      SHome()));
                                        } else {
                                          _tcPassword.text = '';
                                          ScaffoldMessenger.of(context)
                                              .removeCurrentSnackBar();
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(SnackBar(
                                            content: Text(
                                                'Wrong password. Please Try Again. '),
                                            duration: Duration(seconds: 1),
                                          ));
                                        }
                                      });
                                    }
                                  });
                                }
                              },
                              child: Text('Login')),
                        ],
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white),
                          onPressed: () {
                            Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => SRegister()));
                          },
                          child: Text(
                            'No account? Register here.',
                            style: TextStyle(
                                color: Color.fromARGB(255, 117, 7, 7)),
                          ))
                    ],
                  ),
                ),
              );
            })));
  }
}
