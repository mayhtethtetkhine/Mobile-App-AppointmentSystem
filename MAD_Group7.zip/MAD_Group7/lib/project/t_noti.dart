import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'provider.dart';
import 't_home.dart';
import 't_profile.dart';
import 'first.dart';
import 't_create_appoint.dart';

class TNotif extends StatefulWidget {
  const TNotif({super.key});

  @override
  State<TNotif> createState() => _TNotifState();
}

enum TabItem { tab1, tab2, tab3, tab4, tab5 }

class _TNotifState extends State<TNotif> {
  var _currentTab = TabItem.tab1;

  void _selectedTab(TabItem tabItem) {
    setState(() => _currentTab = tabItem);
  }

  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: THome(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 1) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => TNotif()));
    } else if (index == 2) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: CtAppoint(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else if (index == 3) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: TProfile(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  TextEditingController _message = TextEditingController();
  String status = 'Waiting';

  void updateStatus(String id) {
    String sts = status;
    String msg = _message.text;

    FirebaseFirestore.instance
        .collection('booking_data')
        .doc(id)
        .update({'status': sts, 'message': msg});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 255, 252, 247),
      appBar: AppBar(
        title: const Text(
          'Requested Appointments',
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 117, 7, 7),
                Color.fromARGB(255, 175, 71, 71)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                        title: Text("Log Out"),
                        content: Text('Are you sure to log out?'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text(
                              'Back',
                              style: TextStyle(color: Colors.redAccent),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => First()),
                                (route) => false,
                              );
                            },
                            child: const Text('Confirm',
                                style: TextStyle(color: Colors.green)),
                          ),
                        ],
                      ));
            },
            icon: Icon(Icons.logout),
          )
        ],
      ),
      body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('booking_data')
              .where('teacher email',
                  isEqualTo:
                      context.read<AppointmentProvider>().returnTeacherEmail())
              .where('status', isEqualTo: 'Waiting')
              .snapshots(),
          builder: ((context, snapshot) {
            if (snapshot.hasError) {
              return Text('Connection error');
            }

            //is it connecting?
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text('Loading data ...');
            }

            var booking_data = snapshot.data!.docs;

            if (booking_data.isEmpty) {
              return Center(
                  child: Text(
                '~ No appointment request received ~',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 117, 7, 7)),
              ));
            }

            return StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('student_data')
                  .snapshots(),
              builder: ((context, snapshot2) {
                if (snapshot2.hasError) {
                  return Text('Connection error');
                }

                //is it connecting?
                if (snapshot2.connectionState == ConnectionState.waiting) {
                  return Text('Loading data ...');
                }

                var student_data = snapshot2.data!.docs;

                for (int index = 0; index < student_data.length; index++) {
                  context.read<AppointmentProvider>().set_student_data(
                      student_data[index]['student id'],
                      student_data[index]['student name']);
                }

                return Column(
                  children: [
                    Expanded(
                      flex: 3,
                      child: ListView.builder(
                          itemCount: booking_data.length,
                          itemBuilder: ((context, index) {
                            return Padding(
                              padding: const EdgeInsets.all(3.0),
                              child: Card(
                                color: Color.fromARGB(255, 251, 230, 230),
                                shadowColor: Colors.grey,
                                child: ListTileTheme(
                                  textColor: Color.fromARGB(255, 117, 7, 7),
                                  iconColor: Color.fromARGB(255, 117, 7, 7),
                                  child: ListTile(
                                    leading: Icon(Icons.people),
                                    title: Text(booking_data[index]['title']),
                                    subtitle: Text(
                                        'Request by: ${context.read<AppointmentProvider>().get_student_name(booking_data[index]['student id'])}'),
                                    onTap: () {
                                      showDialog(
                                        context: context,
                                        builder: (_) => AlertDialog(
                                          title: Text(
                                              '${booking_data[index]['title']}'),
                                          content: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                  'Date: ${booking_data[index]['date']}'),

                                              Text(
                                                  'Time :  ${booking_data[index]['start time']} - ${booking_data[index]['end time']} '),

                                              Text(
                                                  'Location: ${booking_data[index]['location']}'),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Text(
                                                  'Request by : ${context.read<AppointmentProvider>().get_student_name(booking_data[index]['student id'])} (${booking_data[index]['student id']})'), //example
                                              const SizedBox(height: 10.0),

                                              const Text(
                                                'Add Message: ',
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              const SizedBox(height: 5.0),
                                              TextFormField(
                                                controller: _message,
                                                decoration: InputDecoration(
                                                  hintText: 'Enter message',
                                                  border: OutlineInputBorder(),
                                                ),
                                              ),
                                            ],
                                          ),
                                          actions: <Widget>[
                                            TextButton(
                                              onPressed: () {
                                                status = "Denied";
                                                updateStatus(
                                                    booking_data[index].id);
                                                Navigator.of(context).pop();
                                              },
                                              child: const Text('Decline',
                                                  style: TextStyle(
                                                      color: Colors.redAccent)),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                status = "Confirmed";
                                                updateStatus(
                                                    booking_data[index].id);
                                                Navigator.of(context).pop();
                                                // Add code to submit data
                                              },
                                              child: const Text(
                                                'Approve',
                                                style: TextStyle(
                                                    color: Colors.green),
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            );
                          })),
                    ),
                  ],
                );
              }),
            );
          })),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notification_add_outlined),
            label: 'Check',
            backgroundColor: Color.fromARGB(255, 250, 230, 208),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.create),
            label: 'Create',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
