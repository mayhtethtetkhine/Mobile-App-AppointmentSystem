import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

import 'meeting.dart';
import 'provider.dart';
import 'first.dart';
import 's_create_appoint.dart';
import 's_noti.dart';
import 's_profile.dart';
import 'booking_data_source.dart';

class SHome extends StatefulWidget {
  const SHome({Key? key}) : super(key: key);

  @override
  State<SHome> createState() => _SHomeState();
}

enum TabItem { tab1, tab2, tab3, tab4 }

class _SHomeState extends State<SHome> {
  var _currentTab = TabItem.tab1; //bottombar

  @override
  void initState() {
    super.initState();
  }

  void _selectedTab(TabItem tabItem) {
    setState(() => _currentTab = tabItem);
  }

  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => const SHome()));
    } else if (index == 1) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: const SNotif(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else if (index == 2) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: const CsAppoint(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else if (index == 3) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: const SProfile(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  final format2 = DateFormat('dd-MM-yyyy h:mm');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Home'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                          title: Text("Log Out"),
                          content: Text('Are you sure to log out?'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: const Text(
                                'Back',
                                style: TextStyle(color: Colors.redAccent),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => First()),
                                  (route) => false,
                                );
                              },
                              child: const Text('Confirm',
                                  style: TextStyle(color: Colors.green)),
                            ),
                          ],
                        ));
              },
              icon: Icon(Icons.logout),
            )
          ],
        ),
        body: StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('teacher_data')
                .snapshots(),
            builder: ((context, snapshot2) {
              if (snapshot2.hasError) {
                return Text('Connection error');
              }

              //is it connecting?
              if (snapshot2.connectionState == ConnectionState.waiting) {
                return Text('Loading data ...');
              }

              var teacher_data = snapshot2.data!.docs;

              for (int index = 0; index < teacher_data.length; index++) {
                context.read<AppointmentProvider>().set_teacher_data(
                    teacher_data[index]['teacher email'],
                    teacher_data[index]['teacher name']);
              }

              return StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('booking_data')
                      .where('student id',
                          isEqualTo: context
                              .read<AppointmentProvider>()
                              .returnStudentID())
                      .where('status', isEqualTo: 'Confirmed')
                      .snapshots(),
                  builder: ((context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Connection error');
                    }

                    // is it connecting?
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Text('');
                    }

                    //data is ready

                    var booking_data = snapshot.data!.docs;

                    List<Meeting> meetings = [];
                    final format = DateFormat('dd-MM-yyyy');
                    final yesterday =
                        DateTime.now().subtract(Duration(days: 1));
                    for (int i = 0; i < booking_data.length; i++) {
                      if (format
                          .parse(booking_data[i]['date'])
                          .isBefore(yesterday)) {
                        FirebaseFirestore.instance
                            .collection('booking_data')
                            .doc(booking_data[i].id)
                            .update({'status': 'Expired'});
                      }
                    }

                    for (int i = 0; i < booking_data.length; i++) {
                      String startDateTime = booking_data[i]['date'] +
                          ' ' +
                          booking_data[i]['start time'];
                      String endDateTime = booking_data[i]['date'] +
                          ' ' +
                          booking_data[i]['end time'];
                      bool existing = false;
                      for (int j = 0; j < meetings.length; j++) {
                        if (meetings[j].title == booking_data[i]['title'] &&
                            meetings[j].from == format2.parse(startDateTime)) {
                          existing = true;
                        }
                      }
                      if (existing == false) {
                        meetings.add(Meeting(
                          booking_data[i]['title'],
                          format2.parse(startDateTime),
                          format2.parse(endDateTime),
                          const Color(0xFF0F8644),
                          booking_data[i]['teacher email'],
                          booking_data[i]['location'],
                        ));
                      }
                    }

                    return Column(children: [
                      Expanded(
                        flex: 5,
                        child: SfCalendar(
                          view: CalendarView.month,
                          onTap: (CalendarTapDetails details) {
                            if (details.targetElement ==
                                CalendarElement.appointment) {
                              final Meeting meeting = details.appointments![0];
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      title: Text(meeting.title),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              "Date : ${meeting.from.toString().substring(0, 10)}"),
                                          Text("Location: ${meeting.location}"),
                                          SizedBox(height: 12),
                                          Text(
                                              "Teacher Email : ${meeting.idemail}"),
                                          Text(
                                              "Teacher Name: ${context.read<AppointmentProvider>().get_teacher_name(meeting.idemail)}"),
                                        ],
                                      ),
                                    );
                                  });
                            }
                          },
                          todayHighlightColor: Color.fromARGB(255, 175, 71, 71),
                          backgroundColor: Colors.transparent,
                          selectionDecoration: BoxDecoration(
                              color: Colors.transparent,
                              border: Border.all(
                                  color: Color.fromARGB(255, 117, 7, 7),
                                  width: 2),
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(4)),
                              shape: BoxShape.rectangle),
                          dataSource: BookingDataSource(meetings),
                          monthViewSettings: MonthViewSettings(
                            appointmentDisplayMode:
                                MonthAppointmentDisplayMode.indicator,
                            showAgenda: true,
                          ),
                        ),
                      ),
                    ]);
                  }));
            })),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
              backgroundColor: Color.fromARGB(255, 250, 230, 208),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notification_add_outlined),
              label: 'Check',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.create),
              label: 'Create',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ));
  }
}
