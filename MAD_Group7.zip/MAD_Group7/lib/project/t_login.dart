import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'first.dart';
import 'provider.dart';
import 't_home.dart';
import 't_register.dart';

class TLogin extends StatefulWidget {
  const TLogin({super.key});

  @override
  State<TLogin> createState() => _TLoginState();
}

class _TLoginState extends State<TLogin> {
  final _formkey = GlobalKey<FormState>();

  final _tcTEmail = TextEditingController();
  final _tcTeaPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Login'),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 117, 7, 7),
                Color.fromARGB(255, 175, 71, 71)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        //backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 30),
        child: Form(
          key: _formkey,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: _tcTEmail,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter Email';
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: _tcTeaPassword,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter password';
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white),
                      onPressed: () {
                        //validate
                        //route
                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (context) => First()));
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: Color.fromARGB(255, 117, 7, 7),
                      )),
                  SizedBox(
                    width: 20,
                  ),
                  ElevatedButton(
                      onPressed: () {
                        if (_formkey.currentState!.validate()) {
                          FirebaseFirestore.instance
                              .collection('teacher_data')
                              .where('teacher email', isEqualTo: _tcTEmail.text)
                              .limit(1)
                              .get()
                              .then((QuerySnapshot query) {
                            var docs = query.docs;
                            if (docs.isEmpty) {
                              setState(() {
                                //snackbar account does not exist
                                ScaffoldMessenger.of(context)
                                    .removeCurrentSnackBar();
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  content: Text('Account does not exist. '),
                                  duration: Duration(seconds: 1),
                                ));
                              });
                            } else {
                              setState(() {
                                if (docs[0]['t password'] ==
                                    _tcTeaPassword.text) {
                                  context
                                      .read<AppointmentProvider>()
                                      .set_teacher(_tcTEmail.text);
                                  ScaffoldMessenger.of(context)
                                      .removeCurrentSnackBar();
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(SnackBar(
                                    content: Text('Logged In.'),
                                    duration: Duration(seconds: 1),
                                  ));
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => THome()));
                                } else {
                                  _tcTeaPassword.text = '';
                                  ScaffoldMessenger.of(context)
                                      .removeCurrentSnackBar();
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(SnackBar(
                                    content: Text(
                                        'Wrong password. Please Try Again. '),
                                    duration: Duration(seconds: 1),
                                  ));
                                }
                              });
                            }
                          });
                        }
                      },
                      child: Text('Login')),
                ],
              ),
              SizedBox(
                height: 15,
              ),
              ElevatedButton(
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.white),
                  onPressed: () {
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => TRegister()));
                  },
                  child: Text(
                    'No account? Register here.',
                    style: TextStyle(color: Color.fromARGB(255, 117, 7, 7)),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
