import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:time_range/time_range.dart';

import 'first.dart';
import 'provider.dart';
import 's_home.dart';
import 's_noti.dart';
import 's_profile.dart';
import 'search_teacher.dart';

class CsAppoint extends StatefulWidget {
  const CsAppoint({super.key});

  @override
  State<CsAppoint> createState() => _CsAppointState();
}

enum TabItem { tab1, tab2, tab3, tab4, tab5 }

class _CsAppointState extends State<CsAppoint> {
  final _formkey = GlobalKey<FormState>();
  final _tcTitle = TextEditingController();
  TextEditingController _tcTEmail = TextEditingController();

  final _tcDate = TextEditingController();
  final _tcTime = TextEditingController();
  final _tcLocation = TextEditingController();

  String startTime = '';
  String endTime = '';

  var _currentTab = TabItem.tab3;

  void _selectedTab(TabItem tabItem) {
    setState(() => _currentTab = tabItem);
  }

  Future<void> addData() async {
    String title = _tcTitle.text;
    String trEmail = _tcTEmail.text;
    String student_id = context.read<AppointmentProvider>().returnStudentID();
    String date = _tcDate.text;
    String s_time = startTime;
    String e_time = endTime;
    String location = _tcLocation.text;

    var data = {
      'date': date,
      'location': location,
      'message': '',
      'status': 'Waiting',
      'student id': student_id,
      'teacher email': trEmail,
      'start time': s_time,
      'end time': e_time,
      'title': title
    };

    FirebaseFirestore.instance.collection('booking_data').add(data).then(
        (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Appointment Request Sent'),
              duration: Duration(seconds: 1),
            )),
        onError: (e) => print('Error $e'));
  }

  int _selectedIndex = 2;

  String formatTime(TimeOfDay time) {
    final hours = time.hour.toString().padLeft(2, '0');
    final mins = time.minute.toString().padLeft(2, '0');

    return '$hours:$mins';
  }

  void _onItemTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: SHome(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 1) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: SNotif(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 2) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => CsAppoint()));
    } else if (index == 3) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: SProfile(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Create Appointment'),
        // backgroundColor: Colors.green,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 117, 7, 7),
                Color.fromARGB(255, 175, 71, 71)
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                        title: Text("Log Out"),
                        content: Text('Are you sure to log out?'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text(
                              'Back',
                              style: TextStyle(color: Colors.redAccent),
                            ),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pushAndRemoveUntil(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => First()),
                                (route) => false,
                              );
                            },
                            child: const Text('Confirm',
                                style: TextStyle(color: Colors.green)),
                          ),
                        ],
                      ));
            },
            icon: Icon(Icons.logout),
          )
        ],
      ),
      body: SingleChildScrollView(
          child: Form(
        key: _formkey,
        child: Column(children: [
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: _tcTitle,
              onChanged: (value) {},
              decoration: InputDecoration(
                labelText: 'Appointment Title',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter meeting title';
                }

                return null;
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
                controller: _tcTEmail,
                decoration: InputDecoration(labelText: 'Teacher Email'),
                readOnly: true,
                onTap: () async {
                  final temail = await Navigator.push(context,
                      MaterialPageRoute(builder: (context) => SearchT()));

                  _tcTEmail.text = temail;
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter Teacher Email';
                  }
                  return null;
                }),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextFormField(
                controller: _tcDate,
                decoration: InputDecoration(labelText: 'Date'),
                readOnly: true,
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.parse(
                          DateTime.now().add(Duration(days: 3)).toString()),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.parse(
                          DateTime.now().add(Duration(days: 150)).toString()));

                  if (pickedDate != null) {
                    String formattedDate =
                        DateFormat('dd-MM-yyyy').format(pickedDate);
                    setState(() {
                      _tcDate.text =
                          formattedDate; //set output date to TextField value.
                    });
                  }
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please choose Date';
                  }
                  return null;
                }),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
                controller: _tcTime,
                decoration: InputDecoration(labelText: 'Time'),
                readOnly: true,
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                            title: Text('Select Time'),
                            content: TimeRange(
                              fromTitle: Text(
                                'Start',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Color.fromARGB(255, 117, 7, 7),
                                ),
                              ),
                              toTitle: Text(
                                'End',
                                style: TextStyle(
                                    fontSize: 16,
                                    color: Color.fromARGB(255, 117, 7, 7)),
                              ),
                              titlePadding: 18,
                              textStyle: TextStyle(
                                  fontWeight: FontWeight.normal,
                                  color: Color.fromARGB(255, 117, 7, 7)),
                              activeTextStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                              borderColor: Color.fromARGB(255, 117, 7, 7),
                              backgroundColor: Colors.transparent,
                              activeBackgroundColor:
                                  Color.fromARGB(255, 117, 7, 7),
                              activeBorderColor: Colors.white,
                              firstTime: TimeOfDay(hour: 8, minute: 00),
                              lastTime: TimeOfDay(hour: 17, minute: 00),
                              timeStep: 60,
                              timeBlock: 60,
                              onRangeCompleted: (range) => setState(() {
                                startTime = formatTime(range!.start);
                                endTime = formatTime(range.end);
                                if (startTime == "12:00") {
                                  startTime = "12:10";
                                }
                                if (endTime == "12:00") {
                                  endTime = "11:50";
                                }

                                _tcTime.text = '$startTime - $endTime';
                              }),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                child: const Text(
                                  'OK',
                                  style: TextStyle(
                                    color: Color.fromARGB(255, 117, 7, 7),
                                  ),
                                ),
                              ),
                            ],
                          ));
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select Time correctly';
                  }
                  return null;
                }),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextFormField(
              controller: _tcLocation,
              onChanged: (value) {},
              decoration: InputDecoration(
                labelText: 'Location',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter Location';
                }
                return null;
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(3.0),
            child: ElevatedButton(
              onPressed: () {
                if (_formkey.currentState!.validate()) {
                  addData();
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => SHome()));
                }
              },
              child: Text('Create'),
            ),
          )
        ]),
      )),
      // }
      // )),

      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notification_add_outlined),
            label: 'Check',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.create),
            label: 'Create',
            backgroundColor: Color.fromARGB(255, 250, 230, 208),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
