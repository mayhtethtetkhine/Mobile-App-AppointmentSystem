import 'dart:convert';
import 'dart:ffi';
import 'package:avatars/avatars.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 't_create_appoint.dart';
import 't_noti.dart';
import 'first.dart';
import 'provider.dart';
import 't_home.dart';

class TProfile extends StatefulWidget {
  const TProfile({super.key});

  @override
  State<TProfile> createState() => TProfileState();
}

enum TabItem { tab1, tab2, tab3, tab4 }

class TProfileState extends State<TProfile> {
  var _currentTab = TabItem.tab2;

  void _selectedTab(TabItem tabItem) {
    setState(() => _currentTab = tabItem);
  }

  int _selectedIndex = 3;

  void _onItemTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: THome(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 1) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: TNotif(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 2) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: CtAppoint(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 3) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => TProfile()));
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  final _userStream =
      FirebaseFirestore.instance.collection('teacher_data').snapshots();
  final _formkey = GlobalKey<FormState>();
  TextEditingController _tcEmail = TextEditingController();
  TextEditingController _tcName = TextEditingController();
  TextEditingController _tcPassword = TextEditingController();
  TextEditingController _tcNewPsw = TextEditingController();
  TextEditingController _tcNewPsw2 = TextEditingController();

  Future<void> editProfile(String docsEmail) async {
    _tcPassword.text = '';
    String? answer = await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Edit name'),
            content: Form(
              key: _formkey,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextFormField(
                  controller: _tcName,
                  decoration: InputDecoration(labelText: 'Name'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Name cannot be blank';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 14,
                ),
                TextFormField(
                  controller: _tcPassword,
                  obscureText: true,
                  decoration:
                      InputDecoration(labelText: 'Enter password to confirm'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter password';
                    }
                    return null;
                  },
                ),
              ]),
            ),
            actions: <Widget>[
              TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    'Cancel',
                    style: TextStyle(color: Colors.red),
                  )),
              TextButton(
                  onPressed: () {
                    if (_formkey.currentState!.validate()) {
                      FirebaseFirestore.instance
                          .collection('teacher_data')
                          .where('teacher email',
                              isEqualTo: context
                                  .read<AppointmentProvider>()
                                  .returnTeacherEmail())
                          .limit(1)
                          .get()
                          .then((QuerySnapshot query) {
                        var docs = query.docs;

                        if (docs[0]['t password'] == _tcPassword.text) {
                          Navigator.of(context).pop(docs[0]['teacher email']);
                        } else {
                          Navigator.of(context).pop('error');
                          //ScaffoldMessenger.of(context).removeCurrentSnackBar();
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('Wrong password. Please Try Again. '),
                            duration: Duration(seconds: 1),
                          ));
                        }
                      });
                    }
                  },
                  child: Text('OK'))
            ],
          );
        });

    if (answer != 'error' &&
        _tcName.text != '' &&
        _tcPassword.text != '' &&
        answer != null) {
      var data = {
        'teacher email': answer,
        'teacher name': _tcName.text,
        't password': _tcPassword.text
      };
      FirebaseFirestore.instance
          .collection('teacher_data')
          .doc(docsEmail)
          .update(data)
          .then(
              (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Name Updated successfully'),
                    duration: Duration(seconds: 1),
                  )),
              onError: (e) => print('Error $e'));
    }
  }

  Future<void> editPassword(String docsEmail) async {
    _tcPassword.text = '';
    _tcNewPsw.text = '';
    _tcNewPsw2.text = '';
    String? answer = await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Change Password'),
            content: Form(
              key: _formkey,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextFormField(
                  obscureText: true,
                  controller: _tcPassword,
                  decoration: InputDecoration(labelText: 'Current Password'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Current Password cannot be blank';
                    }

                    return null;
                  },
                ),
                SizedBox(
                  height: 14,
                ),
                TextFormField(
                  controller: _tcNewPsw,
                  obscureText: true,
                  decoration: InputDecoration(labelText: 'New Password'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'New Password cannot be blank';
                    } else if (value == _tcPassword.text) {
                      return 'New password cannot be current password';
                    }
                    return null;
                  },
                ),
                SizedBox(
                  height: 14,
                ),
                TextFormField(
                  controller: _tcNewPsw2,
                  obscureText: true,
                  decoration:
                      InputDecoration(labelText: 'Confirm new password'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Enter new password again';
                    } else if (value != _tcNewPsw.text) {
                      return 'Confirm password do not match';
                    }
                    return null;
                  },
                ),
              ]),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('Back', style: TextStyle(color: Colors.red)),
              ),
              TextButton(
                  onPressed: () {
                    if (_formkey.currentState!.validate()) {
                      FirebaseFirestore.instance
                          .collection('teacher_data')
                          .where('teacher email',
                              isEqualTo: context
                                  .read<AppointmentProvider>()
                                  .returnTeacherEmail())
                          .limit(1)
                          .get()
                          .then((QuerySnapshot query) {
                        var docs = query.docs;

                        if (docs[0]['t password'] == _tcPassword.text) {
                          Navigator.of(context).pop(docs[0]['teacher email']);
                        } else {
                          ScaffoldMessenger.of(context).removeCurrentSnackBar();
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('Incorrect Current Password'),
                            duration: Duration(seconds: 1),
                          ));
                          Navigator.of(context).pop('error');
                        }
                      });
                    }
                  },
                  child: Text('OK'))
            ],
          );
        });

    if (answer != 'error' &&
        _tcName.text != '' &&
        _tcPassword.text != '' &&
        answer != null) {
      var data = {
        'teacher email': answer,
        'teacher name': _tcName.text,
        't password': _tcNewPsw.text
      };

      FirebaseFirestore.instance
          .collection('teacher_data')
          .doc(docsEmail)
          .update(data)
          .then(
              (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Password Updated successfully'),
                    duration: Duration(seconds: 1),
                  )),
              onError: (e) => print('Error $e'));
    }
  }

  String name = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Teacher Profile'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                          title: Text("Log Out"),
                          content: Text('Are you sure to log out?'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: const Text(
                                'Back',
                                style: TextStyle(color: Colors.redAccent),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => First()),
                                  (route) => false,
                                );
                              },
                              child: const Text('Confirm',
                                  style: TextStyle(color: Colors.green)),
                            ),
                          ],
                        ));
              },
              icon: Icon(Icons.logout),
            )
          ],
        ),
        body: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(children: [
              Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: StreamBuilder<QuerySnapshot>(
                      stream: _userStream,
                      builder: ((context, snapshot) {
                        if (snapshot.hasError) {
                          return Text('Connection error');
                        }

                        //is it connecting?
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Text('Loading data ...');
                        }

                        //data is ready
                        // convert data to list
                        var teacher_data = snapshot.data!.docs;
                        String t_email = context
                            .read<AppointmentProvider>()
                            .returnTeacherEmail();

                        String docsEmail = '';
                        int i = 0;
                        for (i; i < teacher_data.length; i++) {
                          if (teacher_data[i]['teacher email'] == t_email) {
                            docsEmail = teacher_data[i].id;
                            break;
                          }
                        }

                        return Column(children: [
                          Avatar(
                              elevation: 3,
                              shape: AvatarShape.rectangle(65, 65,
                                  BorderRadius.all(new Radius.circular(20.0))),
                              name: teacher_data[i]['teacher name']),
                          SizedBox(height: 20),
                          Row(children: [
                            Text('Email',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Color.fromARGB(255, 117, 7, 7))),
                          ]),
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(9.0),
                                child: Text(t_email),
                              ),
                            ],
                          ),
                          Divider(),
                          SizedBox(
                            height: 12,
                          ),
                          Row(
                            children: [
                              Text('Name',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Color.fromARGB(255, 117, 7, 7))),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(9.0),
                                child: Text(teacher_data[i]['teacher name']),
                              ),
                              IconButton(
                                  onPressed: () {
                                    _tcName.text =
                                        teacher_data[i]['teacher name'];
                                    editProfile(docsEmail);
                                  },
                                  icon: Icon(Icons.edit)),
                            ],
                          ),
                          Divider(),
                          SizedBox(
                            height: 12,
                          ),
                          TextButton(
                              onPressed: () {
                                _tcName.text = context
                                    .read<AppointmentProvider>()
                                    .g_teacher_name(teacher_data);
                                editPassword(docsEmail);
                              },
                              child: Text(
                                'Change Password',
                                style: TextStyle(
                                  color: Color.fromARGB(255, 117, 7, 7),
                                ),
                              ))
                        ]);
                      })))
            ])),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notification_add_outlined),
              label: 'Check',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.create),
              label: 'Create',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
              backgroundColor: Color.fromARGB(255, 250, 230, 208),
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ));
  }
}
