import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'provider.dart';
import 's_create_appoint.dart';
import 's_home.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'first.dart';
import 's_profile.dart';

class SNotif extends StatefulWidget {
  const SNotif({super.key});

  @override
  State<SNotif> createState() => _SNotifState();
}

enum TabItem { tab1, tab2, tab3, tab4 }

class _SNotifState extends State<SNotif> {
  var _currentTab = TabItem.tab2;

  void _selectedTab(TabItem tabItem) {
    setState(() => _currentTab = tabItem);
  }

  int _selectedIndex = 1;

  void _onItemTapped(int index) {
    if (index == 0) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: SHome(),
              type: PageTransitionType.leftToRightJoined,
              childCurrent: widget));
    } else if (index == 1) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => SNotif()));
    } else if (index == 2) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: CsAppoint(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else if (index == 3) {
      Navigator.pushReplacement(
          context,
          PageTransition(
              child: SProfile(),
              type: PageTransitionType.rightToLeftJoined,
              childCurrent: widget));
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  final _userStream2 =
      FirebaseFirestore.instance.collection('teacher_data').snapshots();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Notifications'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          actions: [
            IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                          title: Text("Log Out"),
                          content: Text('Are you sure to log out?'),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: const Text(
                                'Back',
                                style: TextStyle(color: Colors.redAccent),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => First()),
                                  (route) => false,
                                );
                              },
                              child: const Text('Confirm',
                                  style: TextStyle(color: Colors.green)),
                            ),
                          ],
                        ));
              },
              icon: Icon(Icons.logout),
            )
          ],
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('booking_data')
              .where('student id',
                  isEqualTo:
                      context.read<AppointmentProvider>().returnStudentID())
              .where('status',
                  whereIn: ['Confirmed', 'Denied', 'Waiting']).snapshots(),
          builder: ((context, snapshot) {
            if (snapshot.hasError) {
              return Text('Connection error');
            }

            //is it connecting?
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text('Loading data ...');
            }

            //data is ready

            // convert data to list
            var booking_data = snapshot.data!.docs;

            if (booking_data.isEmpty) {
              return const Center(
                  child: Text(
                '~ No appointment request sent or received ~',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 117, 7, 7)),
              ));
            }

            return StreamBuilder<QuerySnapshot>(
              stream: _userStream2,
              builder: ((context2, snapshot2) {
                if (snapshot2.hasError) {
                  return Text('Connection error');
                }

                //is it connecting?
                if (snapshot2.connectionState == ConnectionState.waiting) {
                  return Text('Loading data ...');
                }

                var teacher_data = snapshot2.data!.docs;

                for (int index = 0; index < teacher_data.length; index++) {
                  context.read<AppointmentProvider>().set_teacher_data(
                      teacher_data[index]['teacher email'],
                      teacher_data[index]['teacher name']);
                }

                return Column(children: [
                  Expanded(
                    flex: 1,
                    child: Center(
                      child: Text(
                        'Replied Appointments',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 5,
                    child: ListView.builder(
                      itemCount: context
                          .read<AppointmentProvider>()
                          .get_replied(booking_data)
                          .length,
                      itemBuilder: ((context, index) {
                        return Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Card(
                            color: context
                                .read<AppointmentProvider>()
                                .cardColor(context
                                        .read<AppointmentProvider>()
                                        .get_replied(booking_data)[index]
                                    ['status']),
                            shadowColor: Colors.grey,
                            child: ListTileTheme(
                              textColor: Colors.black,
                              iconColor: Colors.black,
                              child: ListTile(
                                leading: Icon(Icons.people),
                                title: Text(
                                    '${context.read<AppointmentProvider>().get_replied(booking_data)[index]['title']}'),
                                subtitle: Text(
                                    'Teacher: ${context.read<AppointmentProvider>().get_teacher_name(context.read<AppointmentProvider>().get_replied(booking_data)[index]['teacher email'])}'),
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => AlertDialog(
                                      title: Text(
                                          '${context.read<AppointmentProvider>().get_replied(booking_data)[index]['title']}'),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              'Date: ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['date']} \nTime: ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['start time']} - ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['end time']}\nLocation: ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['location']}\n'),
                                          Text(
                                            'Status: ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['status']}',
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                              'Message: ${context.read<AppointmentProvider>().get_replied(booking_data)[index]['message']} '),
                                          const SizedBox(height: 10.0),

                                          Text(
                                              'Reply from:\n${context.read<AppointmentProvider>().get_teacher_name(context.read<AppointmentProvider>().get_replied(booking_data)[index]['teacher email'])} (${booking_data[index]['teacher email']})'), //example
                                          const SizedBox(height: 10.0),
                                        ],
                                      ),
                                      actions: <Widget>[
                                        TextButton(
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                          child: const Text('OK'),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                  Divider(),
                  Expanded(
                    flex: 1,
                    child: Center(
                      child: Text(
                        'Waiting',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 5,
                    child: ListView.builder(
                      itemCount: context
                          .read<AppointmentProvider>()
                          .get_waiting(booking_data)
                          .length,
                      itemBuilder: ((context, index) {
                        return Padding(
                          padding: const EdgeInsets.all(3.0),
                          child: Card(
                            color: context
                                .read<AppointmentProvider>()
                                .cardColor(context
                                        .read<AppointmentProvider>()
                                        .get_waiting(booking_data)[index]
                                    ['status']),
                            shadowColor: Colors.grey,
                            child: ListTileTheme(
                              textColor: Colors.black,
                              iconColor: Colors.black,
                              child: ListTile(
                                leading: Icon(Icons.people),
                                title: Text(context
                                    .read<AppointmentProvider>()
                                    .get_waiting(booking_data)[index]['title']),
                                subtitle: Text(
                                    'Teacher: ${context.read<AppointmentProvider>().get_teacher_name(context.read<AppointmentProvider>().get_waiting(booking_data)[index]['teacher email'])}'),
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => AlertDialog(
                                      title: Text(
                                          '${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['title']}'),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              'Date: ${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['date']} \nTime: ${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['start time']} - ${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['end time']}\nLocation: ${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['location']}\n\nWaiting for:\n${context.read<AppointmentProvider>().get_teacher_name(context.read<AppointmentProvider>().get_waiting(booking_data)[index]['teacher email'])} (${context.read<AppointmentProvider>().get_waiting(booking_data)[index]['teacher email']})'), //example
                                          const SizedBox(height: 10.0),
                                        ],
                                      ),
                                      actions: <Widget>[
                                        TextButton(
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                          child: const Text('OK'),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  )
                ]);
              }),
            );
          }),
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notification_add_outlined),
              label: 'Check',
              backgroundColor: Color.fromARGB(255, 250, 230, 208),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.create),
              label: 'Create',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
        ));
  }
}
