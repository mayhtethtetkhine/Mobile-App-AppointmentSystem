import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class SearchS extends StatefulWidget {
  const SearchS({super.key});

  @override
  State<SearchS> createState() => _SearchSState();
}

class _SearchSState extends State<SearchS> {
  @override
  void initState() {
    _searchController.addListener(_onSearchChanged);
    getTrStream();
    super.initState();
  }

  _onSearchChanged() {
    searchResultList();
  }

  @override
  void didChangeDependencies() {
    getTrStream();
    super.didChangeDependencies();
  }

  List _allResults = [];
  List _resultList = [];

  final TextEditingController _searchController = TextEditingController();
  getTrStream() async {
    var data =
        await FirebaseFirestore.instance.collection('student_data').get();
    setState(() {
      _allResults = data.docs;
    });
    searchResultList();
  }

  searchResultList() {
    var showResults = [];
    if (_searchController.text != "") {
      for (var tsnapshot in _allResults) {
        var name = tsnapshot['student name'].toString().toLowerCase();
        if (name.contains(_searchController.text.toLowerCase())) {
          showResults.add(tsnapshot);
        }
      }
    } else {
      showResults = List.from(_allResults);
    }

    setState(() {
      _resultList = showResults;
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Search Student',
          ),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        body: Column(
          children: [
            Expanded(
                flex: 1,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    autofocus: true,
                    controller: _searchController,
                    decoration: const InputDecoration(
                        labelText: 'Search Student',
                        suffixIcon: Icon(
                          Icons.search,
                          color: Color.fromARGB(255, 117, 7, 7),
                        )),
                  ),
                )),
            Expanded(
              flex: 7,
              child: ListView.builder(
                  itemCount: _resultList.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        title: Text(_resultList[index]['student name']),
                        subtitle: Text(_resultList[index]['student id']),
                        onTap: () {
                          Navigator.pop(
                              context, _resultList[index]['student id']);
                        },
                      ),
                    );
                  }),
            ),
          ],
        ));
  }
}
