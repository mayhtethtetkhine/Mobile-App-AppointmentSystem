import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'first.dart';
import 's_login.dart';

class SRegister extends StatefulWidget {
  SRegister({super.key});

  @override
  State<SRegister> createState() => _SRegisterState();
}

class _SRegisterState extends State<SRegister> {
  final _userStream =
      FirebaseFirestore.instance.collection('student_data').snapshots();
  final _formkey = GlobalKey<FormState>();
  final _focus = FocusNode();
  TextEditingController _tcName = TextEditingController();
  TextEditingController _tcStudentId = TextEditingController();
  TextEditingController _tcPassword = TextEditingController();
  TextEditingController _tcPassword2 = TextEditingController();
  TextEditingController _tcSchool = TextEditingController();

  Future<void> addData() async {
    String name = _tcName.text;
    String id = _tcStudentId.text;
    String password = _tcPassword.text;
    String school = _tcSchool.text;

    var data = {
      'student name': name,
      'student id': id,
      's password': password,
      's degree': school,
    };

    FirebaseFirestore.instance.collection('student_data').add(data).then(
        (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Account created. '),
              duration: Duration(seconds: 1),
            )),
        onError: (e) => print('Error $e'));
  }

  final List<String> items1 = [
    'School of Agro-Industry',
    'School of Cosmetic Science',
    'School of Health Science',
    'School of Information Technology',
    'School of Integrative Medicine',
    'School of Law',
    'School of Liberal Arts',
    'School of Management',
    'School of Nursing',
    'School of Science',
    'School of Sinology',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Student Register'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        body: StreamBuilder<QuerySnapshot>(
            stream: _userStream,
            builder: ((context, snapshot) {
              if (snapshot.hasError) {
                return Text('Connection error');
              }

              //is it connecting?
              if (snapshot.connectionState == ConnectionState.waiting) {
                return Text('Loading data ...');
              }

              //data is ready

              // convert data to list
              var existing_data = snapshot.data!.docs;

              return SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    Padding(
                        padding: const EdgeInsets.only(top: 30),
                        child: Form(
                            key: _formkey,
                            child: Column(children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  autofocus: true,
                                  focusNode: _focus,
                                  controller: _tcName,
                                  decoration: InputDecoration(
                                    labelText: 'Name',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter your name';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  controller: _tcStudentId,
                                  decoration: InputDecoration(
                                    labelText: 'Student ID',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Student ID';
                                    } else if (int.tryParse(value) == null) {
                                      return 'Please enter number only';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  controller: _tcSchool,
                                  readOnly: true,
                                  decoration:
                                      InputDecoration(labelText: 'School'),
                                  onTap: () {
                                    showDialog(
                                        context: context,
                                        builder: (_) => AlertDialog(
                                            title: Text('Choose School'),
                                            content: ListView.builder(
                                                itemCount: items1.length,
                                                itemBuilder: ((context, index) {
                                                  return ListTile(
                                                    title: Text(
                                                      items1[index],
                                                      style: TextStyle(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Color.fromARGB(
                                                              255, 117, 7, 7)),
                                                    ),
                                                    onTap: () {
                                                      _tcSchool.text =
                                                          items1[index];
                                                      Navigator.pop(context);
                                                    },
                                                  );
                                                }))));
                                  },
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please choose school';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  controller: _tcPassword,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    labelText: 'Password',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Password';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: TextFormField(
                                  controller: _tcPassword2,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    labelText: 'Confirm Password',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please re-enter Password to confirm';
                                    } else if (value != _tcPassword.text) {
                                      return 'Confirm password do not match';
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.white),
                                      onPressed: () {
                                        //validate
                                        //route
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) => First()));
                                      },
                                      child: Icon(
                                        Icons.arrow_back,
                                        color: Color.fromARGB(255, 175, 71, 71),
                                      )),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  ElevatedButton(
                                      onPressed: () {
                                        bool create = true;
                                        if (_formkey.currentState!.validate()) {
                                          for (int i = 0;
                                              i < existing_data.length;
                                              i++) {
                                            if (_tcStudentId.text ==
                                                existing_data[i]
                                                    ['student id']) {
                                              create = false;
                                            }
                                          }
                                          if (create == true) {
                                            addData();
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SLogin()));
                                          } else {
                                            ScaffoldMessenger.of(context)
                                                .showSnackBar(SnackBar(
                                              content: Text(
                                                  'Cannot create account. (Existing)'),
                                              duration: Duration(seconds: 1),
                                            ));
                                            Navigator.pushReplacement(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        SLogin()));
                                          }
                                        }
                                      },
                                      child: Text('Register')),
                                ],
                              ),
                            ])))
                  ],
                ),
              );
            })));
  }
}
