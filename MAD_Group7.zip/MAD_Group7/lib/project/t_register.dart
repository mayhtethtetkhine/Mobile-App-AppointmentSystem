import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'first.dart';
import 't_login.dart';

class TRegister extends StatefulWidget {
  const TRegister({super.key});

  @override
  State<TRegister> createState() => _TRegisterState();
}

class _TRegisterState extends State<TRegister> {
  final _teaStream =
      FirebaseFirestore.instance.collection('taecher_data').snapshots();
  final _formkey = GlobalKey<FormState>();
  final _focus = FocusNode();
  TextEditingController _tcTname = TextEditingController();
  TextEditingController _tcTEmail = TextEditingController();
  TextEditingController _tcTPassword = TextEditingController();
  TextEditingController _tcTPassword2 = TextEditingController();

  Future<void> addData() async {
    String Tname = _tcTname.text;
    String Temail = _tcTEmail.text;
    String Tpassword = _tcTPassword.text;

    var data = {
      'teacher name': Tname,
      'teacher email': Temail,
      't password': Tpassword
    };

    FirebaseFirestore.instance.collection('teacher_data').add(data).then(
        (value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Account created. '),
              duration: Duration(seconds: 1),
            )),
        onError: (e) => print('Error $e'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Teacher Register'),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 117, 7, 7),
                  Color.fromARGB(255, 175, 71, 71)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
        ),
        body: StreamBuilder<QuerySnapshot>(
          stream: _teaStream,
          builder: ((context, snapshot) {
            if (snapshot.hasError) {
              return Text('Connection error');
            }

            //is it connecting?
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text('Loading data ...');
            }

            //data is ready

            // convert data to list
            var existing_data = snapshot.data!.docs;

            return Padding(
                padding: const EdgeInsets.only(top: 30),
                child: Form(
                  key: _formkey,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          autofocus: true,
                          focusNode: _focus,
                          controller: _tcTname,
                          decoration: InputDecoration(
                            labelText: 'Name',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your name';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _tcTEmail,
                          decoration: InputDecoration(
                            labelText: 'Email',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Email';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _tcTPassword,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Password',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter Password';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _tcTPassword2,
                          obscureText: true,
                          decoration: InputDecoration(
                            labelText: 'Confirm Password',
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please re-enter Password to confirm';
                            } else if (value != _tcTPassword.text) {
                              return 'Confirm password do not match';
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white),
                              onPressed: () {
                                //validate
                                //route
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => First()));
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Color.fromARGB(255, 175, 71, 71),
                              )),
                          SizedBox(
                            width: 20,
                          ),
                          ElevatedButton(
                              onPressed: () {
                                bool create = true;
                                if (_formkey.currentState!.validate()) {
                                  for (int i = 0;
                                      i < existing_data.length;
                                      i++) {
                                    if (_tcTEmail.text ==
                                        existing_data[i]['teacher email']) {
                                      create = false;
                                    }
                                  }
                                  if (create == true) {
                                    addData();
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => TLogin()));
                                  } else {
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: Text(
                                          'Cannot create account. (Existing)'),
                                      duration: Duration(seconds: 1),
                                    ));
                                    Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => TLogin()));
                                  }
                                }
                              },
                              child: Text('Register')),
                        ],
                      ),
                    ],
                  ),
                ));
          }),
        ));
  }
}
