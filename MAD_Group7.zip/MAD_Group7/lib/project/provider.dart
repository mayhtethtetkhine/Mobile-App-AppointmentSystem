import 'package:flutter/material.dart';

const Color approveColor = Color.fromARGB(86, 184, 247, 186);
const Color deniedColor = Color.fromARGB(157, 253, 166, 166);

class AppointmentProvider with ChangeNotifier {
  String student_id = '';
  String teacher_email = '';
  String searched_temail = '';

  void set_temail(String email) {
    searched_temail = email;
    notifyListeners();
  }

  void clear_temail() {
    searched_temail = '';
  }

  String return_searched() {
    return searched_temail;
  }

  List<Map<String, dynamic>> teacher_data = [
    {'teacher email': '', 'teacher name': ''}
  ];
  List<Map<String, dynamic>> student_data = [
    {'student id': '', 'student name': ''}
  ];

  // String student_psw = '';

  String get_teacher_name(String email) {
    for (int i = 0; i < teacher_data.length; i++) {
      String? name;
      if (email == teacher_data[i]['teacher email']) {
        name = teacher_data[i]['teacher name'];
      }
      if (name != null) {
        return name;
      }
    }
    return 'No teacher found';
  }

  String? get_student_name(String id) {
    for (int i = 0; i < student_data.length; i++) {
      String? name;

      if (id == student_data[i]['student id']) {
        name = student_data[i]['student name'];
      }
      if (name != null) {
        return name;
      }
    }

    return 'No student found';
  }

  void set_teacher_data(String email, String name) {
    bool exist = false;

    int i = 0;
    for (i; i < teacher_data.length; i++) {
      if (teacher_data[i]['teacher email'] == email) {
        exist = true;
      }
    }
    if (exist == false) {
      List<Map<String, dynamic>> data = [
        {'teacher email': email, 'teacher name': name}
      ];
      teacher_data.add(data[0]);
    }
  }

  void set_student_data(String sid, String name) {
    bool existing = false;

    int i = 0;
    for (i; i < student_data.length; i++) {
      if (student_data[i]['student id'] == sid) {
        existing = true;
      }
    }
    if (existing == false) {
      List<Map<String, dynamic>> data = [
        {'student id': sid, 'student name': name}
      ];
      student_data.add(data[0]);
    }
  }

  String g_student_name(List docs) {
    for (int i = 0; i < docs.length; i++) {
      if (student_id == docs[i]['student id']) {
        return docs[i]['student name'];
      }
    }
    return 'error';
  }

  String g_teacher_name(List docs) {
    for (int i = 0; i < docs.length; i++) {
      if (teacher_email == docs[i]['teacher email']) {
        return docs[i]['teacher name'];
      }
    }
    return 'error';
  }

  Color cardColor(String status) {
    if (status == 'Confirmed') {
      return approveColor;
    } else if (status == 'Denied') {
      return deniedColor;
    }
    return Color.fromARGB(255, 244, 237, 177);
  }

  void set_student(String id) {
    student_id = id;
    // student_psw = psw;
  }

  void set_teacher(String email) {
    teacher_email = email;
    // student_psw = psw;
  }

  String returnStudentID() {
    return student_id;
  }

  String returnTeacherEmail() {
    return teacher_email;
  }

  List get_replied(List booking_data) {
    List replied_data = [];
    for (int i = 0; i < booking_data.length; i++) {
      if (booking_data[i]['status'] != 'Waiting' &&
          booking_data[i]['status'] != 'Expired') {
        replied_data.add(booking_data[i]);
      }
    }

    return replied_data;
  }

  List get_waiting(List booking_data) {
    List waiting_data = [];
    for (int i = 0; i < booking_data.length; i++) {
      if (booking_data[i]['status'] == 'Waiting') {
        waiting_data.add(booking_data[i]);
      }
    }

    return waiting_data;
  }

  List get_approved(List booking_data) {
    List approved_data = [];
    for (int i = 0; i < booking_data.length; i++) {
      if (booking_data[i]['status'] == 'Confirmed') {
        approved_data.add(booking_data[i]);
      }
    }

    return approved_data;
  }
}
